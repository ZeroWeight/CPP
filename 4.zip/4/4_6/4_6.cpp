#include <iostream>

/*
 * ������
 * ˽�����ݳ�ԱΪʵ�����鲿
 * �ɴ���ʵ�����鲿���� ��ֻ����ʵ�����鲿Ϊ0��
 * ���ظ�ֵ����
 */
class Complex
{
public:
	Complex(void);
	Complex(const Complex &c);
	Complex(const double &re);
	Complex(const double &re, const double &im);
	~Complex(void);
	Complex &operator =(const Complex &c);
	void add(const Complex &c);
	void show(void) const;

private:
	double m_re, m_im;
};

int main(int argc, char **argv)
{
	Complex c1(3, 5);
	Complex c2 = 4.5;
	c1.add(c2);
	c1.show();
	return 0;
}

Complex::Complex(void)
{

}

Complex::Complex(const Complex &c)
{
	m_re = c.m_re;
	m_im = c.m_im;
}

Complex::Complex(const double &re)
{
	m_re = re;
	m_im = 0.0;
}

Complex::Complex(const double &re, const double &im)
{
	m_re = re;
	m_im = im;
}

Complex::~Complex(void)
{

}

Complex &Complex::operator =(const Complex &c)
{
	m_re = c.m_re;
	m_im = c.m_im;
	return *this;
}

void Complex::add(const Complex &c)
{
	m_re += c.m_re;
	m_im += c.m_im;
}

void Complex::show(void) const
{
	std::cout << m_re << '+' << m_im << 'i' << std::endl;
}