#include <iostream>

enum CPU_Rank
{
	P1 = 1,
	P2,
	P3,
	P4,
	P5,
	P6,
	P7
};

class CPU
{
public:
	CPU(void);
	CPU(CPU_Rank r, int f, double v);
	~CPU(void);
	void run(void) const;
	void stop(void) const;
	
private:
	CPU_Rank rank;
	int frequency;
	double voltage;
};

int main(int argc, char **argv)
{
	CPU cpu(P1, 2, 1.5);
	cpu.run();
	cpu.stop();
	return 0;
}

CPU::CPU(void)
{
	std::cout << "Calling default construction function!" << std::endl;
}

CPU::CPU(CPU_Rank r, int f, double v)
{
	rank = r;
	frequency = f;
	voltage = v;
	std::cout << "Calling construction function!" << std::endl;
}

CPU::~CPU(void)
{
	std::cout << "Calling destruction function!" << std::endl;
}

void CPU::run(void) const
{
	std::cout << "Run!" << std::endl;
}

void CPU::stop(void) const
{
	std::cout << "Stop!" << std::endl;
}