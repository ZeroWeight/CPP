#include <iostream>

/*
 * ����
 * ˽�����ݳ�ԱΪ���ƽ������
 * �ɴ��������x, yֵ����
 * ���ظ�ֵ����
 */
class Point
{
public:
	Point(void);
	Point(const Point &p);
	Point(const double &x, const double &y);
	~Point(void);
	Point &operator =(const Point &p);
	double GetX(void) const;
	double GetY(void) const;

private:
	double m_x, m_y;
};

/*
 * ������
 * ˽�����ݳ�ԱΪ���½Ǻ����Ͻǵĵ�
 * �ɴ��������㹹�� �����δ���������ĸ�ֵ����
 * ���ظ�ֵ����
 */
class Rectangle
{
public:
	Rectangle(void);
	Rectangle(const Rectangle &rect);
	Rectangle(const Point &lwrlft, const Point &uprrht);
	Rectangle(const double &llx, const double &lly,
			  const double &urx, const double &ury);
	~Rectangle(void);
	Rectangle &operator =(const Rectangle &rect);
	double GetArea(void) const;

private:
	Point m_lwrlft, m_uprrht;
};

int main(int argc, char **argv)
{
	Rectangle rect(1.5, 2.5, 9.3, 3.4);
	std::cout << "The area of the rectangle is " << rect.GetArea() << std::endl;
	return 0;
}

Point::Point(void)
{

}

Point::Point(const Point &p)
{
	m_x = p.m_x;
	m_y = p.m_y;
}

Point::Point(const double &x, const double &y)
{
	m_x = x;
	m_y = y;
}

Point::~Point(void)
{

}

Point &Point::operator =(const Point &p)
{
	m_x = p.m_x;
	m_y = p.m_y;
	return *this;
}

double Point::GetX(void) const
{
	return m_x;
}

double Point::GetY(void) const
{
	return m_y;
}

Rectangle::Rectangle(void)
{

}

Rectangle::Rectangle(const Rectangle &rect)
{
	m_lwrlft = rect.m_lwrlft;
	m_uprrht = rect.m_uprrht;
}

Rectangle::Rectangle(const Point &lwrlft, const Point &uprrht)
{
	m_lwrlft = lwrlft;
	m_uprrht = uprrht;
}

Rectangle::Rectangle(const double &llx, const double &lly,
					 const double &urx, const double &ury)
{
	m_lwrlft = Point(llx, lly);
	m_uprrht = Point(urx, ury);
}

Rectangle::~Rectangle(void)
{

}

Rectangle &Rectangle::operator =(const Rectangle &rect)
{
	m_lwrlft = rect.m_lwrlft;
	m_uprrht = rect.m_uprrht;
	return *this;
}

double Rectangle::GetArea(void) const
{
	return (m_uprrht.GetX() - m_lwrlft.GetX()) * (m_uprrht.GetY() - m_lwrlft.GetY());
}