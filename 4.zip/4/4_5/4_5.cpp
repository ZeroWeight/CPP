#include <iostream>

const double PI = 3.14159;

/*
 * Բ��
 * ˽�����ݳ�ԱΪԲ�İ뾶
 * �ɴ���뾶��ֵ����
 */
class Circle
{
public:
	Circle(void);
	Circle(const Circle &cir);
	Circle(const double &r);
	~Circle(void);
	double GetArea(void) const;

private:
	double m_radius;
};

int main(int argc, char **argv)
{
	Circle cir(3.0);
	std::cout << "The area of the circle is " << cir.GetArea() << std::endl;
	return 0;
}

Circle::Circle(void)
{

}

Circle::Circle(const Circle &cir)
{
	m_radius = cir.m_radius;
}

Circle::Circle(const double &r)
{
	m_radius = r;
}

Circle::~Circle(void)
{

}

double Circle::GetArea(void) const
{
	return PI * m_radius * m_radius;
}