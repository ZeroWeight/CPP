#include "ta.h"
#include <cstring>

TA::TA(void) : Graduate()
{

}

TA::TA(const TA &ta) : Graduate(ta)
{
	strcpy_s(m_principalship, ta.m_principalship);
	strcpy_s(m_department, ta.m_department);
}

TA::TA(const char *name, const char *number, const char *sex, const Date &birthday, const char *id, const char *classNo,
	   const char *subject, const Teacher &adviser, const char *principalship, const char *department)
	   : Graduate(name, number, sex, birthday, id, classNo, subject, adviser)
{
	strcpy_s(m_principalship, principalship);
	strcpy_s(m_department, department);
}

TA::~TA(void)
{

}

void TA::Display(void) const
{
	std::cout << "Name: " << m_name << std::endl;
	std::cout << "Number: " << m_number << std::endl;
	std::cout << "Sex: " << m_sex << std::endl;
	std::cout << "Birthday: " << *m_birthday << std::endl;
	std::cout << "Id: " << m_id << std::endl;
	std::cout << "ClassNo: " << m_classNo << std::endl;
	std::cout << "Subject: " << m_subject << std::endl;
	std::cout << "Adviser: ================" << std::endl;
	m_adviser.Display();
	std::cout << "=========================" << std::endl;
	std::cout << "Principalship: " << m_principalship << std::endl;
	std::cout << "Department: " << m_department << std::endl;
}