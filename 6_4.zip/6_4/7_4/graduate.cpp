#include "graduate.h"
#include <cstring>

Graduate::Graduate(void) : Student()
{

}

Graduate::Graduate(const Graduate &graduate) : Student(graduate)
{
	strcpy_s(m_subject, graduate.m_subject);
	m_adviser = graduate.m_adviser;
}

Graduate::Graduate(const char *name, const char *number, const char *sex, const Date &birthday, const char *id, const char *classNo,
				   const char *subject, const Teacher &adviser) : Student(name, number, sex, birthday, id, classNo)
{
	strcpy_s(m_subject, subject);
	m_adviser = adviser;
}

Graduate::~Graduate(void)
{

}

void Graduate::SetSubject(const char *subject)
{
	strcpy_s(m_subject, subject);
}

void Graduate::SetAdviser(const Teacher &adviser)
{
	m_adviser = adviser;
}

void Graduate::Display(void) const
{
	std::cout << "Name: " << m_name << std::endl;
	std::cout << "Number: " << m_number << std::endl;
	std::cout << "Sex: " << m_sex << std::endl;
	std::cout << "Birthday: " << *m_birthday << std::endl;
	std::cout << "Id: " << m_id << std::endl;
	std::cout << "ClassNo: " << m_classNo << std::endl;
	std::cout << "Subject: " << m_subject << std::endl;
	std::cout << "Adviser: ================" << std::endl;
	m_adviser.Display();
	std::cout << "=========================" << std::endl;
}