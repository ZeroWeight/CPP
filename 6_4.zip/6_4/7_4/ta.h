#ifndef TA_H
#define TA_H

#include "graduate.h"
#include "teacher.h"

class TA : public Graduate, public Teacher
{
public:
	TA(void);
	TA(const TA &ta);
	TA(const char *name, const char *number, const char *sex, const Date &birthday, const char *id, const char *classNo,
		const char *subject, const Teacher &adviser, const char *principalship, const char *department);
	~TA(void);

	void Display(void) const;
};

#endif