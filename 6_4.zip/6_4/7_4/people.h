#ifndef PEOPLE_H
#define PEOPLE_H

#include "date.h"

class People
{
public:
	People(void);
	People(const People &people);
	People(const char *name, const char *number, const char *sex, const Date &birthday, const char *id);
	~People(void);

	void SetName(const char *name);
	void SetNumber(const char *number);
	void SetSex(const char *sex);
	void SetBirthday(const Date &birthday);
	void SetBirthday(const int &year, const int &month, const int &day);
	void SetId(const char *id);
	virtual void Display(void) const;

protected:
	char m_name[11];
	char m_number[7];
	char m_sex[3];
	Date *m_birthday;
	char m_id[16];
};

#endif