#include "people.h"
#include <cstring>

People::People(void)
{
	m_birthday = new Date();
}

People::People(const People &people)
{
	strcpy_s(m_name, people.m_name);
	strcpy_s(m_number, people.m_number);
	strcpy_s(m_sex, people.m_sex);
	m_birthday = new Date(*people.m_birthday);
	strcpy_s(m_id, people.m_id);
}

People::People(const char *name, const char *number, const char *sex, const Date &birthday, const char *id)
{
	strcpy_s(m_name, name);
	strcpy_s(m_number, number);
	strcpy_s(m_sex, sex);
	m_birthday = new Date(birthday);
	strcpy_s(m_id, id);
}

People::~People(void)
{
	delete m_birthday;
}

void People::SetName(const char *name)
{
	strcpy_s(m_name, name);
}

void People::SetNumber(const char *number)
{
	strcpy_s(m_number, number);
}

void People::SetSex(const char *sex)
{
	strcpy_s(m_sex, sex);
}

void People::SetBirthday(const Date &birthday)
{
	m_birthday->SetDate(birthday);
}

void People::SetBirthday(const int &year, const int &month, const int &day)
{
	m_birthday->SetDate(year, month, day);
}

void People::SetId(const char *id)
{
	strcpy_s(m_id, id);
}

void People::Display(void) const
{
	std::cout << "Name: " << m_name << std::endl;
	std::cout << "Number: " << m_number << std::endl;
	std::cout << "Sex: " << m_sex << std::endl;
	std::cout << "Birthday: " << *m_birthday << std::endl;
	std::cout << "Id: " << m_id << std::endl;
}