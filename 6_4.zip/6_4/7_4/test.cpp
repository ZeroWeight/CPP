#include "ta.h"

int main(int argc, const char **argv)
{
	Teacher teacher("Zhang San", "001", "WM", Date(1980, 1, 1), "123456123456789", "Chairman", "Teaching Department");
	teacher.Display();
	std::cout << std::endl;
	Student student("Li Si", "002", "M", Date(1995, 3, 1), "654321987654321", "5");
	student.Display();
	std::cout << std::endl;
	Graduate graduate("Li Si", "002", "M", Date(1995, 3, 1), "654321987654321", "5", "Math", teacher);
	graduate.Display();
	std::cout << std::endl;
	TA ta("Li Si", "002", "M", Date(1995, 3, 1), "654321987654321", "5", "Math", teacher, "TA", "NONE");
	ta.Display();
	return 0;
}