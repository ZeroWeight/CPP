#include "student.h"
#include <cstring>

Student::Student(void) : People()
{

}

Student::Student(const Student &student) : People(student)
{
	strcpy_s(m_classNo, student.m_classNo);
}

Student::Student(const char *name, const char *number, const char *sex, const Date &birthday,
				 const char *id, const char *classNo) : People(name, number, sex, birthday, id)
{
	strcpy_s(m_classNo, classNo);
}

Student::~Student(void)
{

}

void Student::SetClassNo(const char *classNo)
{
	strcpy_s(m_classNo, classNo);
}

void Student::Display(void) const
{
	std::cout << "Name: " << m_name << std::endl;
	std::cout << "Number: " << m_number << std::endl;
	std::cout << "Sex: " << m_sex << std::endl;
	std::cout << "Birthday: " << *m_birthday << std::endl;
	std::cout << "Id: " << m_id << std::endl;
	std::cout << "ClassNo: " << m_classNo << std::endl;
}