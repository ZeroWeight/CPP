#ifndef TEACHER_H
#define TEACHER_H

#include "people.h"

class Teacher : virtual public People
{
public:
	using People::People;
	Teacher(void);
	Teacher(const Teacher &teacher);
	Teacher(const char *name, const char *number, const char *sex, const Date &birthday,
		const char *id, const char *principalship, const char *department);
	~Teacher(void);

	void SetPrincipalship(const char *principalship);
	void SetDepartment(const char *department);
	void Display(void) const;

protected:
	char m_principalship[11];
	char m_department[21];
};

#endif