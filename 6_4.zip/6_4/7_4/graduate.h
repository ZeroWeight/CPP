#ifndef GRADUATE_H
#define GRADUATE_H

#include "student.h"
#include "teacher.h"

class Graduate : virtual public Student
{
public:
	Graduate(void);
	Graduate(const Graduate &graduate);
	Graduate(const char *name, const char *number, const char *sex, const Date &birthday,
		const char *id, const char *classNo, const char *subject, const Teacher &adviser);
	~Graduate(void);

	void SetSubject(const char *subject);
	void SetAdviser(const Teacher &adviser);
	void Display(void) const;

protected:
	char m_subject[21];
	Teacher m_adviser;
};

#endif