#include "date.h"

Date::Date(void)
{

}

Date::Date(const Date &date)
{
	m_year = date.m_year;
	m_month = date.m_month;
	m_day = date.m_day;
}

Date::Date(const int &year, const int &month, const int &day)
{
	m_year = year;
	m_month = month;
	m_day = day;
}

Date::~Date(void)
{

}

void Date::SetDate(const Date &date)
{
	m_year = date.m_year;
	m_month = date.m_month;
	m_day = date.m_day;
}

void Date::SetDate(const int &year, const int &month, const int &day)
{
	m_year = year;
	m_month = month;
	m_day = day;
}

std::ostream &operator <<(std::ostream &out, const Date &date)
{
	out << date.m_year << '-' << date.m_month << '-' << date.m_day;
	return out;
}