#ifndef STUDENT_H
#define STUDENT_H

#include "people.h"

class Student : virtual public People
{
public:
	Student(void);
	Student(const Student &student);
	Student(const char *name, const char *number, const char *sex,
		const Date &birthday, const char *id, const char *classNo);
	~Student(void);

	void SetClassNo(const char *classNo);
	void Display(void) const;

protected:
	char m_classNo[7];
};

#endif