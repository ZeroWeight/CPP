#include "teacher.h"
#include <cstring>

Teacher::Teacher(void) : People()
{

}

Teacher::Teacher(const Teacher &teacher) : People(teacher)
{
	strcpy_s(m_principalship, teacher.m_principalship);
	strcpy_s(m_department, teacher.m_department);
}

Teacher::Teacher(const char *name, const char *number, const char *sex, const Date &birthday, const char *id,
				 const char *principalship, const char *department) : People(name, number, sex, birthday, id)
{
	strcpy_s(m_principalship, principalship);
	strcpy_s(m_department, department);
}

Teacher::~Teacher(void)
{

}

void Teacher::SetPrincipalship(const char *principalship)
{
	strcpy_s(m_principalship, principalship);
}

void Teacher::SetDepartment(const char *department)
{
	strcpy_s(m_department, department);
}

void Teacher::Display(void) const
{
	std::cout << "Name: " << m_name << std::endl;
	std::cout << "Number: " << m_number << std::endl;
	std::cout << "Sex: " << m_sex << std::endl;
	std::cout << "Birthday: " << *m_birthday << std::endl;
	std::cout << "Id: " << m_id << std::endl;
	std::cout << "Principalship: " << m_principalship << std::endl;
	std::cout << "Department: " << m_department << std::endl;
}